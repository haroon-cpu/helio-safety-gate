# HELIO — 2-Minute Founder Demo Video Script (Mozilla Human-Scale AI Incubator 2027)

**Target Runtime:** 1 minute 50 seconds to 2 minutes 0 seconds (Unlisted YouTube video)
**Recording Tip:** Record your laptop screen + your own real voice (English is fine, Mozilla explicitly says perfect English is NOT required—reviewers want to hear your genuine founder voice!).

---

### [0:00 – 0:25] Intro & Real Coimbatore Story (Show your screen / GitHub README)
"Hi Mozilla team, I'm Mohammed Haroon, an 18-year-old engineering student and founder of HEONIX AI in Coimbatore, Tamil Nadu, India. Small 1-to-3 doctor clinics here serve Tamil and Tanglish speaking patients, and they can't afford receptionists or foreign cloud AI bills. When I demoed HELIO at a local dental clinic in Coimbatore, the doctor loved it—but requiring a separate SIM card broke her workflow. And when my own free cloud credits expired, I got a 5,000 rupee bill in just one week. That taught me why clinic AI must be small, local, and clinician-controlled."

### [0:25 – 1:15] Live Terminal Demo (Run `python test_safety_gate.py` in VS Code)
"Let me show you our open-source Apache-2.0 safety layer running completely locally with zero cloud API calls.
Here is a 3-turn Tamil and Tanglish conversation.
Turn 1: A 62-year-old patient mentions diabetes and blood pressure. Acuity stays LOW.
Turn 2: They mention chest heaviness—'nenju pakkam barama irukku'. Acuity rises to ELEVATED.
Turn 3: They mention left arm pain, sweating, and breathing trouble—without ever typing the English words 'heart attack' or 'ambulance'.
Instantly, our deterministic safety gate detects EMERGENCY, routes them to Tamil Nadu's Dial-108 ambulance service, alerts the clinic staff, and triggers our 15-minute clinician ghost-mute so the doctor has complete control and the AI never gives false reassurance."

### [1:15 – 1:45] Privacy & Open-Source Commitment
"We also verify 4-language opt-out respect in Tamil, Tanglish, Hindi, and English, and keep patient identity encrypted locally with AES-256-GCM. Our prototype currently transitions from Gemini API to a 1B-to-2B local model on an 8GB clinic PC."

### [1:45 – 2:00] Closing
"With Mozilla's Human-Scale AI Incubator, we will get local Coimbatore doctors to validate these safety rules, benchmark tiny local Tamil models, and publish our safety gate and synthetic benchmark openly under Apache-2.0. Thank you!"
