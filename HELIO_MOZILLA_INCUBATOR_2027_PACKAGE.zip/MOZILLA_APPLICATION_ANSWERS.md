# Mozilla Foundation Human-Scale AI Incubator 2027 — Initial Project Proposal

**Deadline:** Friday, Nov 20, 2026, 11:59 PM PST (**Saturday, Nov 21, 2026, 1:29 PM IST**)
**IMPORTANT MOZILLA AI-USE POLICY NOTE:** Mozilla allows AI for brainstorming, clarity, and translation, but asks that answers reflect your own voice and work. Before clicking Submit, read each answer below, tweak a few sentences in your own natural words, and disclose AI assistance honestly if asked!

---

## Part 1: Applicant Information & Dropdown Selections
- **Main Contact Name:** Mohammed Haroon J
- **Main Contact Email:** haroon@heonixai.in
- **Applicant Type:** For-profit
- **Organization Legal Name:** HEONIX AI
- **Countries/Regions Served:** India (Coimbatore, Tamil Nadu)
- **Human-Scale Principles:** Check ALL THREE -> `Small`, `Intentional`, `Tailored`
- **Project Stage:** `Working prototype` (Honest! Do not inflate)
- **Product-Community Signals:** `Community`, `Partners` (or `Users` if you count your test sessions; be honest about 1 clinic demo)
- **Current Users:** `<100`
- **Frontier-Model API Dependency:** `Yes` (Honest! Currently uses Gemini API while transitioning to 1B-2B local models)
- **Largest Model Parameter Band:** Select the band matching current prototype (or `1B–3B` if the form asks for target local architecture; clarify clearly in the text box)
- **Charitable-Purpose:** `Yes`
- **Working-in-the-Open Checkboxes:** Check `Open-source code`, `Public documentation`, `Open datasets / benchmarks`
- **Code / Demo / Site URL:** `https://github.com/haroon-cpu/helio-safety-gate` (Upload the `helio-safety-gate/` folder from this ZIP first!) and `https://heonixai.in`

---

## Part 2: Exact Word-Limited Form Answers

### Project Title (Max 10 words) (8/10 words)

HELIO Local Tamil Clinical Coordination and Safety Gate

### Project Summary (Max 50 words) (47/50 words)

HELIO is an offline-first Tamil and Tanglish clinic coordination and emergency safety system for small independent clinics in Coimbatore, India. It combines a deterministic 108 emergency red-flag layer, clinician-controlled 15-minute silence mode, and compact local language models so clinics handle patient intake privately without expensive cloud APIs.

### Public-Benefit Narrative (Max 150 words) (135/150 words)

Small independent clinics in Tamil Nadu serve working-class patients who speak Tamil and code-mixed Tanglish, yet have no budget for digital receptionists or foreign cloud AI subscriptions. When clinics miss patient messages, routine appointments fail and urgent symptoms risk dangerous delays. HELIO serves a clear public benefit by releasing an open-source Apache-2.0 public safety commons: a deterministic Tamil and Tanglish 108 emergency escalation gate, a synthetic vernacular safety benchmark, a clinic threat model, and a local-first privacy blueprint aligned with India's DPDP Act and ABDM consent principles. Clinics and public health teams can reuse these safety tools freely without paying HEONIX AI. If selected, HEONIX AI will complete Mozilla's eligibility review and obtain specialist Indian FCRA, FEMA, and tax advice before funds are received; we are prepared to use an eligible fiscal sponsor if required.

### Technology and Theme (Max 200 words) (180/200 words)

HELIO is not a general-purpose AI doctor or chatbot wrapper. It is a bounded clinical coordination and safety infrastructure built for 1-to-3-doctor outpatient clinics in Tamil Nadu. Our working Python engine separates deterministic safety from language understanding. First, an always-local deterministic safety layer runs 25 boot gates, AES-256-GCM encrypted PII storage, 22-table erasure compliance, and a 3-turn progressive Tamil and Tanglish red-flag detector that routes cardiac or respiratory emergencies directly to Tamil Nadu's Dial-108 ambulance service without generating LLM reassurance. Second, a 15-minute clinician coexistence mode immediately pauses automation whenever a doctor replies manually. Today, our working prototype uses the Gemini API for language parsing while deterministic safety runs locally. After a Rs. 5,000 cloud bill hit in one week when free cloud credits expired, we experienced firsthand why cloud-scale AI fails small Indian clinics. With Mozilla's support, we will replace frontier APIs with a 1B-to-2B quantized local model (benchmarking Gemma 3 1B, Qwen2.5 1.5B, and AI4Bharat IndicBERT-v3-1B) running on an 8GB clinic PC. Before any patient-facing pilot, we will obtain clinician safety sign-off and a CDSCO medical-device classification opinion.

### Small Principle (Max 100 words) (98/100 words)

HELIO deliberately uses less AI, less cloud, and less data. Safety escalation, opt-outs, and scheduling locks run as deterministic Python rules with sub-millisecond latency and zero GPU demand. We are transitioning language normalization from frontier cloud APIs to a 1B-to-2B 4-bit quantized open-weight model plus compact Tamil encoders running locally on standard 8GB clinic PCs. Because TRAI March 2026 data shows uneven rural Tamil Nadu internet access (20.36M rural vs 48.65M urban subscriptions), offline local execution prevents cloud bills and connectivity failures. We will measure real CPU RAM, latency, and power draw on clinic hardware during Year 1.

### Intentional Principle (Max 100 words) (90/100 words)

Patients and clinicians keep full control over data and clinical authority. Routine intake stays local so symptom narratives do not automatically cross borders to foreign cloud APIs, preparing small clinics for India's DPDP Rules taking full effect around May 2027. Our architecture isolates PII inside an AES-256-GCM encrypted vault, supports 22-table cascading deletion, honors 4-language opt-outs with a non-AI staff path, and enforces a 15-minute clinician coexistence mute so doctors never lose control of patient conversations. Emergency rules are deterministic, auditable, and clinician-governed rather than hidden inside a black-box prompt.

### Tailored Principle (Max 100 words) (93/100 words)

HELIO is built specifically around Tamil-speaking patients and small clinics in Coimbatore, Tamil Nadu. Generic English chatbots miss everyday Tanglish phrases like nenju barama irukku or idadhu kai valikkudhu. Our 3-turn progressive detector links age, diabetes or blood pressure history, and escalating symptoms across messages to recommend Tamil Nadu's Dial-108 ambulance service, directly aligning with the state's Heart Attack Management Program launched in Coimbatore at Malumichampatti. Our 15-minute coexistence mode was designed directly after a local Coimbatore dental clinic visit revealed that forcing doctors onto a separate SIM card breaks their real-world workflow.

### Traction and Product-Community Fit (Max 150 words) (135/150 words)

We have a working 49,746-line Python engine verified by 6 adversarial test proofs, 25 boot gates, and multi-process concurrency tests, alongside our newly published Apache-2.0 open-source safety gate repository. In Coimbatore, I conducted an in-person discovery interview and live demo at a local dental clinic. The dentist confirmed she lacked time to answer patient WhatsApp messages, saw clear value for handling clinic volume, and initially agreed to a 14-day trial. However, requiring a new SIM card caused a one-week delay and she opted to reply manually instead. That honest failure gave us our strongest community insight: small doctors must keep their existing number and control. It directly drove us to engineer our 15-minute clinician coexistence mode. Current deployed clinic count is zero; Year 1 begins with 3-to-5 shadow-mode clinics in Coimbatore before any patient-facing rollout.

### Current Blockers (Max 150 words) (125/150 words)

We face four concrete blockers that Mozilla's support directly solves. First, cloud cost: when free Google Cloud credits expired, a Rs. 5,000 bill arrived in one week, proving we must complete our migration to local 1B-to-2B quantized models on 8GB clinic PCs. Second, clinical validation: our Tamil and Tanglish 108 emergency rules are currently a technical prototype and require formal review by 2-to-3 practicing Coimbatore physicians plus a CDSCO medical-device classification opinion before live patient use. Third, real-world clinic baselines: official Coimbatore OPD no-show and waiting-time statistics do not exist, requiring structured four-week pre-deployment measurements across pilot clinics. Fourth, legal grant-receipt compliance: as an Indian Udyam MSME startup, we need specialist FCRA, FEMA, and tax counsel—or an eligible fiscal sponsor—to receive US 501(c)(3) funding cleanly.

### Team (Max 150 words) (125/150 words)

I am Mohammed Haroon J, an 18-year-old undergraduate engineering student at Karpagam Institute of Technology in Coimbatore and Founder of HEONIX AI (Udyam MSME registered and NVIDIA Inception member). I personally architected and tested HELIO's 49,746-line backend, AES-256-GCM PIIVault, 22-table lifecycle privacy engine, and 3-turn Tamil/Tanglish emergency escalation rules. Growing up in Coimbatore, I have lived experience with Tamil clinic workflows and language barriers. While I am currently a solo technical founder, I know a solo student cannot safely deploy clinical AI alone. Year 1 funding directly budgets for ML edge contractors, two Tamil community implementation staff, paid clinical safety consultants, independent cybersecurity auditors, and a Community Advisory Board of 2-to-3 local physicians, clinic staff, and Tamil-speaking patients to govern emergency rules and field deployment.

### Success at 12 and 36 Months (Max 150 words) (115/150 words)

At 12 months (March 2028), success means: completing CDSCO and FCRA legal reviews; benchmarking 1B-to-2B Tamil models on 8GB clinic PCs; validating our 108 safety gate with 2-to-3 Coimbatore physicians; running 3-to-5 shadow-mode clinics and expanding to 10-to-20 pilot clinics only after clinician-approved sensitivity gates pass; and publishing five Apache-2.0 open artifacts including our safety gate, synthetic Tamil/Tanglish clinical evaluation suite, threat model, local-first privacy blueprint, and four-week clinic baseline dataset. At 36 months, success means 100+ small clinics across Tamil Nadu using local-first privacy-preserving coordination, an active Indian developer and clinician community maintaining the open Tamil safety commons, measurable reductions in missed follow-ups and staff workload, and zero dependence on foreign frontier cloud APIs.

### Sustainability and Barriers (Max 150 words) (123/150 words)

Our post-grant sustainability follows an ethical open-core model aligned with Mozilla's values. The public safety commons—deterministic Tamil/Tanglish 108 safety gate, synthetic evaluation suite, threat model, and privacy blueprint—remains permanently free under Apache-2.0 for public clinics, NGOs, and researchers. HEONIX AI sustains operations through low-cost monthly clinic subscriptions for proprietary CRM workflows, scheduling, and local support, with larger clinic-network contracts cross-subsidizing small independent clinics. We will never monetize identifiable patient data. Key barriers include physician trust, CDSCO regulatory classification if wording implies diagnosis, hardware reliability during power cuts, and Tamil dialect variation. We mitigate these by strictly scoping HELIO to intake coordination and red-flag escalation, requiring clinician sign-off before leaving shadow mode, using battery-backed local mini-PCs, and co-designing iteratively with local doctors and patients.

### What $300K Unlocks (Max 150 words) (118/150 words)

The 300,000 USD Year 1 grant unlocks safe, locally validated engineering that is impossible to self-fund as an 18-year-old founder in India. Specifically, it funds full-time technical leadership ($90K), ML edge quantization contractors ($30K), two Tamil clinic implementation staff ($30K), paid clinical safety consultants ($18K), independent clinical safety evaluation ($18K), independent cybersecurity and privacy audit ($12K), edge mini-PCs and backup networking for 10-to-20 Coimbatore pilot sites ($22K), synthetic Tamil/Tanglish benchmark creation ($15K), participatory co-design workshops compensating patients and staff ($15K), open-source documentation ($10K), specialist FCRA/CDSCO/privacy legal counsel ($20K), local fieldwork travel ($10K), and conservative indirect costs ($10K, 3.33 percent). Crucially, it lets us gate every clinical milestone on independent safety audits instead of rushing unsafe prototypes to market.

### Working in the Open (Max 150 words) (113/150 words)

While HEONIX AI retains proprietary rights to its commercial clinic CRM and billing layer, we commit to building our entire safety and privacy foundation in the open under Apache-2.0. We will maintain five public repositories: helio-safety-gate (deterministic Tamil/Tanglish normalization and 108 escalation rules), helio-tamil-clinic-eval (clinician-validated synthetic benchmark covering mixed scripts, misspellings, and hard Tanglish utterances, explicitly labeled non-diagnostic), helio-threat-model (data-flow diagrams and STRIDE privacy analysis), helio-edge-blueprint (local encrypted storage and 22-table deletion patterns), and helio-governance (Community Advisory Board charter and change-control logs). We will never publish real patient records or raw production chat logs. We will share quarterly hardware benchmarks, shadow-mode error analyses, and lessons openly with the Mozilla cohort and global public.

### Novel AI Approach (Max 200 words) (173/200 words)

Most healthcare AI projects wrap a massive frontier cloud LLM around a chat box and ask it to act like a doctor. HELIO takes the opposite, human-scale approach: narrow the AI, harden the boundaries, and keep intelligence local. Our core technical novelty is a hybrid three-layer architecture tailored for low-resource Tamil and Tanglish outpatient clinics. Layer 1 is a zero-LLM deterministic safety gate and 3-turn Clinical Context Graph that tracks risk factors (age, diabetes, hypertension) and progressive vernacular symptoms across turns, triggering immediate Dial-108 escalation and a 15-minute clinician ghost-mute without ever letting an LLM generate false reassurance. Layer 2 uses compact Tamil encoders (such as AI4Bharat IndicBERT-v3-1B) and MIT-licensed IndicTrans2 normalization for predictable intent classification and code-mixed script handling. Layer 3 constrains a 1B-to-2B 4-bit quantized local generative model (such as Gemma 3 1B or Qwen2.5 1.5B) strictly to administrative intake and retrieval from clinician-approved content. Combined with our AES-256-GCM PIIVault and 22-table erasure lifecycle, HELIO proves that tiny, locally governed AI beats frontier cloud wrappers on safety, privacy, latency, and affordability.
